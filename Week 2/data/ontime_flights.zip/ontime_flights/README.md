# On-Time Flight Data #

The attached data set contains the ontime flight information for U.S. flights for the month of January 2013. This data was obtained from the [Research and Innovative Technology Administration (RITA)][rita] and measures the ontime performance of airlines flying from U.S. cities. 

The fields in the data set (in columnar order in the TSV are as follows):

* Year: 4 digt year
* Month: Unpadded month digit
* Day: Unpadded day of month digit
* FlightDate: Date of flight (yyyymmdd)
* AirlineID: A US DOT identification for airline
* Carrier: The text description of the airline
* Origin: The airport code of the origination airport
* OriginCityName: Origin Airport, City Name
* OriginState: Origin Airport, State Code
* Destination: The airport code of the destination airport
* DestCityNAme: Destination Airport, City Name
* DestState: Destination Airport, State Code
* DepartureTime: Actual departure time (local time: hhmm)
* DepartureDelay: Difference in minutes between scheduled time and depature; Negative numbers indicate early depatures
* ArrivalTime: Actual arrival time (local time: hhmm)
* ArrivalDelay: Difference in minutes between scheduled time and arrival Negative numbers indicate early arrivals.
* Cancelled: 1 if the flight was canceld, 0 otherwise
* ElapsedTime: Time of the flight in minutes
* AirTime: Air time of the flight in minutes
* Distance: Distance between origin and destination in miles  

Each field is separated by a tab (`\t`) character. String fields that may contain this character are surrounded by quote (`"`) characters.

The two correlary files: airlines.csv and carriers.csv are lookup tables for the various codes in use at RITA and in this file. The ontime_flights.tsv file has already been updated via the lookup tables, but these files serve as reference.

Data statistics:

* Elapsed time period: 1 month (January 1, 2013- January 30, 2013)
* Number of flights (rows): 509,519
* File size: 62 MB on disk

[rita]: http://www.transtats.bts.gov/DL_SelectFields.asp?Table_ID=236&DB_Short_Name=On-Time "Bureau of Transportation Statitics"
